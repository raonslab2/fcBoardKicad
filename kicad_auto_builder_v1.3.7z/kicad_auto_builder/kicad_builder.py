"""
KiCad Builder - 라이브러리 및 회로도 생성 v1.3

심볼/풋프린트 라이브러리 병합 및 회로도 자동 생성.
와이어 자동 생성 기능 포함 (그리드 스냅 + L자 라우팅).
v1.2: 계층 시트 지원
v1.3: BOM 고도화 (MPN, manufacturer, DNP, quantity grouping, report.md)
"""

import csv
import json
import logging
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Optional

from .config_loader import ProjectConfig
from .part_resolver import ResolvedPart
from .templates.symbol import SymbolTemplate, BUILTIN_SYMBOLS
from .templates.schematic import SchematicTemplate

logger = logging.getLogger(__name__)

# KiCad 그리드 크기 (mm)
GRID_SIZE = 2.54


def snap_to_grid(value: float, grid: float = GRID_SIZE) -> float:
    """값을 그리드에 스냅합니다."""
    return round(value / grid) * grid


class KicadBuilder:
    """KiCad 라이브러리 및 회로도 빌더."""

    def __init__(self, config: ProjectConfig, resolved_parts: list[ResolvedPart]):
        """초기화.

        Args:
            config: 프로젝트 설정
            resolved_parts: 리졸브된 부품 목록
        """
        self.config = config
        self.parts = resolved_parts

        # 출력 디렉토리 생성
        self.output_dir = Path(config.out_dir)
        self.lib_dir = self.output_dir / "lib"
        self.lib_dir.mkdir(parents=True, exist_ok=True)

    def build_all(self, warnings: list[str] = None):
        """전체 빌드 실행.

        Args:
            warnings: 검증 단계에서 발생한 경고 목록 (manifest에 포함)
        """
        logger.info("=" * 60)
        logger.info(f"프로젝트 빌드: {self.config.name}")
        logger.info("=" * 60)

        # 1. 심볼 라이브러리 생성
        sym_path = self.build_symbol_library()
        logger.info(f"[OK] 심볼 라이브러리: {sym_path}")

        # 2. 풋프린트 라이브러리 생성 (복사)
        fp_path = self.build_footprint_library()
        if fp_path:
            logger.info(f"[OK] 풋프린트 라이브러리: {fp_path}")

        # 3. 회로도 생성 (단일/계층 모드)
        if self.config.is_hierarchical:
            sch_paths = self.build_hierarchical_schematics()
            sch_path = sch_paths["root"]
            for name, path in sch_paths.items():
                logger.info(f"[OK] 회로도 ({name}): {path}")
        else:
            sch_path = self.build_schematic()
            logger.info(f"[OK] 회로도: {sch_path}")

        # 4. BOM 생성 (v1.3: JLC + Full)
        bom_path = self.build_bom()
        logger.info(f"[OK] BOM (JLC): {bom_path}")

        bom_full_path = self.build_bom_full()
        logger.info(f"[OK] BOM (Full): {bom_full_path}")

        # 5. Report 생성 (v1.3)
        report_path = self.build_report(warnings or [])
        logger.info(f"[OK] Report: {report_path}")

        # 6. Manifest 생성
        result = {
            "symbol_lib": sym_path,
            "footprint_lib": fp_path,
            "schematic": sch_path,
            "bom_jlc": bom_path,
            "bom_full": bom_full_path,
            "report": report_path,
        }
        manifest_path = self.build_manifest(result, warnings or [])
        logger.info(f"[OK] Manifest: {manifest_path}")
        result["manifest"] = manifest_path

        logger.info("=" * 60)
        logger.info("빌드 완료!")
        logger.info("=" * 60)

        return result

    def build_symbol_library(self) -> Path:
        """심볼 라이브러리를 생성합니다."""
        symbols = []
        added_symbols = set()

        # 네트 프리셋에서 전원 심볼 추가
        for net_name, net_value in self.config.net_presets.items():
            if net_value.upper() == "GND":
                if "GND" not in added_symbols:
                    symbols.append(BUILTIN_SYMBOLS["GND"])
                    added_symbols.add("GND")
            else:
                # 전원 심볼 생성
                sym_name = net_value.replace(".", "V").replace("+", "")
                if sym_name not in added_symbols:
                    # 내장 심볼 확인
                    builtin = SymbolTemplate.get_builtin_symbol(net_value)
                    if builtin:
                        symbols.append(builtin)
                    else:
                        symbols.append(SymbolTemplate.create_power_symbol(net_value, net_value))
                    added_symbols.add(net_value)

        # 각 부품의 심볼 추가
        for part in self.parts:
            sym_name = part.symbol_name

            if sym_name in added_symbols:
                continue

            # 1. LCSC에서 가져온 심볼 파일이 있으면 사용
            if part.symbol_lib and part.symbol_lib.exists():
                content = part.symbol_lib.read_text(encoding='utf-8')
                # 라이브러리 헤더/푸터 제거하고 심볼만 추출
                sym_content = self._extract_symbol_from_lib(content)
                if sym_content:
                    symbols.append(sym_content)
                    added_symbols.add(sym_name)
                    continue

            # 2. 내장 심볼 확인
            builtin = SymbolTemplate.get_builtin_symbol(sym_name)
            if builtin:
                symbols.append(builtin)
                added_symbols.add(sym_name)
                continue

            # 3. 없으면 경고
            logger.warning(f"심볼 없음: {sym_name} ({part.ref})")

        # 라이브러리 파일 생성
        lib_content = SymbolTemplate.create_library(symbols, "custom")

        output_path = self.lib_dir / "custom.kicad_sym"
        output_path.write_text(lib_content, encoding='utf-8')

        return output_path

    def build_footprint_library(self) -> Optional[Path]:
        """풋프린트 라이브러리를 생성합니다."""
        # .pretty 디렉토리 생성
        fp_dir = self.lib_dir / "custom.pretty"
        fp_dir.mkdir(exist_ok=True)

        copied = 0

        for part in self.parts:
            if part.footprint_lib and part.footprint_lib.exists():
                # .kicad_mod 파일 복사
                dest = fp_dir / part.footprint_lib.name
                if not dest.exists():
                    shutil.copy2(part.footprint_lib, dest)
                    copied += 1

        if copied > 0:
            return fp_dir

        return None

    def build_schematic(self) -> Path:
        """회로도를 생성합니다."""
        # lib_symbols 섹션 생성
        lib_symbols = self._build_lib_symbols_section()

        # 컴포넌트 인스턴스 생성
        components = []
        labels = []
        label_points = defaultdict(list)  # net -> [(x, y), ...]

        for i, part in enumerate(self.parts):
            pos = SchematicTemplate.calculate_grid_position(i)

            # 컴포넌트 인스턴스
            lib_id = f"custom:{part.symbol_name}"
            comp = SchematicTemplate.create_component_instance(
                lib_id=lib_id,
                ref=part.ref,
                value=part.value,
                x=pos.x,
                y=pos.y,
                footprint=part.footprint_full,
                lcsc=part.lcsc,
                project=self.config.name,
            )
            components.append(comp)

            # 네트 라벨 추가 (각 핀에 대해)
            label_y = pos.y - 10.16
            for pin_name, net_name in part.nets.items():
                # 그리드 스냅
                snapped_x = snap_to_grid(pos.x)
                snapped_y = snap_to_grid(label_y)

                label = SchematicTemplate.create_label(
                    name=net_name,
                    x=snapped_x,
                    y=snapped_y,
                )
                labels.append(label)

                # 와이어 생성용 좌표 기록
                label_points[net_name].append((snapped_x, snapped_y))

                label_y -= 2.54

        # 전원 심볼 인스턴스 추가
        power_symbols = []
        power_y = 30.0

        for net_name, net_value in self.config.net_presets.items():
            lib_id = f"custom:{net_value}"
            rotation = 180 if net_value.upper() == "GND" else 0

            power = SchematicTemplate.create_power_instance(
                lib_id=lib_id,
                value=net_value,
                x=250.0,
                y=power_y,
                rotation=rotation,
                project=self.config.name,
            )
            power_symbols.append(power)
            power_y += 15.0

        # 와이어 생성
        wires_str = self._generate_wires(label_points)

        # 제목 텍스트
        title_text = SchematicTemplate.create_text(
            text=f"{self.config.name}\\n\\nAuto-generated schematic\\nParts: {len(self.parts)}",
            x=25.0,
            y=25.0,
        )

        # 회로도 생성
        schematic = SchematicTemplate.create_schematic(
            project_name=self.config.name,
            lib_symbols=lib_symbols,
            components="\n".join(components + power_symbols),
            wires=wires_str,
            labels="\n".join(labels),
            texts=title_text,
        )

        output_path = self.output_dir / f"{self.config.name}.kicad_sch"
        output_path.write_text(schematic, encoding='utf-8')

        return output_path

    def build_hierarchical_schematics(self) -> dict[str, Path]:
        """계층 시트 구조의 회로도를 생성합니다 (v1.2).

        Returns:
            {"root": Path, "sheet_name": Path, ...}
        """
        results = {}

        # 시트별 리졸브된 부품 매핑
        sheet_parts_map = {}
        ref_to_resolved = {p.ref: p for p in self.parts}

        for sheet in self.config.sheets:
            sheet_parts_map[sheet.name] = [
                ref_to_resolved[p.ref]
                for p in sheet.parts
                if p.ref in ref_to_resolved
            ]

        # 1. 각 서브시트 생성
        for sheet in self.config.sheets:
            sheet_path = self._build_sub_sheet(sheet, sheet_parts_map[sheet.name])
            results[sheet.name] = sheet_path

        # 2. 루트 시트 생성
        root_path = self._build_root_sheet()
        results["root"] = root_path

        return results

    def _build_root_sheet(self) -> Path:
        """루트 시트를 생성합니다."""
        # 서브시트 심볼 배치
        sheet_symbols = []
        x, y = 50.0, 50.0

        for i, sheet in enumerate(self.config.sheets):
            # 시트 심볼 크기 계산 (포트 수에 따라)
            pin_count = len(sheet.ports)
            height = max(20.0, (pin_count + 2) * 2.54)

            # 포트 정보를 핀으로 변환
            pins = [{"name": p, "type": "passive"} for p in sheet.ports]

            symbol = SchematicTemplate.create_sheet_symbol(
                name=sheet.name,
                filename=sheet.filename,
                x=x,
                y=y,
                width=30.0,
                height=height,
                pins=pins,
            )
            sheet_symbols.append(symbol)

            # 다음 시트 위치 (가로로 배치)
            x += 50.0
            if (i + 1) % 4 == 0:  # 4개마다 줄바꿈
                x = 50.0
                y += 60.0

        # 타이틀 텍스트
        title_text = SchematicTemplate.create_text(
            text=f"{self.config.name}\\n\\nHierarchical Design\\nSheets: {len(self.config.sheets)}",
            x=25.0,
            y=25.0,
        )

        # 루트 회로도 생성
        root_sch = SchematicTemplate.create_root_schematic(
            project_name=self.config.name,
            lib_symbols="",  # 루트에는 심볼 불필요
            sheet_symbols="\n".join(sheet_symbols),
            texts=title_text,
        )

        output_path = self.output_dir / f"{self.config.name}.kicad_sch"
        output_path.write_text(root_sch, encoding='utf-8')

        return output_path

    def _build_sub_sheet(self, sheet, resolved_parts: list) -> Path:
        """서브시트를 생성합니다."""
        # lib_symbols 섹션 (이 시트에서 사용하는 심볼만)
        lib_symbols = self._build_lib_symbols_for_parts(resolved_parts)

        # 컴포넌트 배치
        components = []
        labels = []
        label_points = defaultdict(list)

        for i, part in enumerate(resolved_parts):
            pos = SchematicTemplate.calculate_grid_position(i)

            lib_id = f"custom:{part.symbol_name}"
            comp = SchematicTemplate.create_component_instance(
                lib_id=lib_id,
                ref=part.ref,
                value=part.value,
                x=pos.x,
                y=pos.y,
                footprint=part.footprint_full,
                lcsc=part.lcsc,
                project=self.config.name,
            )
            components.append(comp)

            # 네트 라벨
            label_y = pos.y - 10.16
            for pin_name, net_name in part.nets.items():
                snapped_x = snap_to_grid(pos.x)
                snapped_y = snap_to_grid(label_y)

                label = SchematicTemplate.create_label(
                    name=net_name,
                    x=snapped_x,
                    y=snapped_y,
                )
                labels.append(label)
                label_points[net_name].append((snapped_x, snapped_y))
                label_y -= 2.54

        # 와이어 생성
        wires_str = self._generate_wires(label_points)

        # 계층 핀 (포트) 생성
        hierarchical_pins = []
        pin_y = 30.0
        for port_name in sheet.ports:
            h_pin = SchematicTemplate.create_hierarchical_pin(
                name=port_name,
                x=25.0,
                y=pin_y,
                shape="passive",
            )
            hierarchical_pins.append(h_pin)
            pin_y += 5.08

        # 타이틀 텍스트
        title_text = SchematicTemplate.create_text(
            text=f"{sheet.name}\\nParts: {len(resolved_parts)}",
            x=25.0,
            y=15.0,
        )

        # 서브시트 생성
        sub_sch = SchematicTemplate.create_sub_schematic(
            sheet_name=sheet.name,
            project_name=self.config.name,
            lib_symbols=lib_symbols,
            components="\n".join(components),
            wires=wires_str,
            labels="\n".join(labels),
            hierarchical_pins="\n".join(hierarchical_pins),
            texts=title_text,
        )

        output_path = self.output_dir / sheet.filename
        output_path.write_text(sub_sch, encoding='utf-8')

        return output_path

    def _build_lib_symbols_for_parts(self, parts: list) -> str:
        """특정 부품 목록에 대한 lib_symbols 섹션을 생성합니다."""
        symbols = []
        added = set()

        for part in parts:
            sym_name = part.symbol_name
            if sym_name in added:
                continue

            # LCSC 심볼
            if part.symbol_lib and part.symbol_lib.exists():
                content = part.symbol_lib.read_text(encoding='utf-8')
                sym_content = self._extract_symbol_from_lib(content)
                if sym_content:
                    symbols.append(self._indent_symbol(sym_content))
                    added.add(sym_name)
                    continue

            # 내장 심볼
            builtin = SymbolTemplate.get_builtin_symbol(sym_name)
            if builtin:
                symbols.append(self._indent_symbol(builtin))
                added.add(sym_name)

        return "\n".join(symbols)

    def _generate_wires(self, label_points: dict[str, list[tuple[float, float]]]) -> str:
        """동일 net 라벨들을 와이어로 연결합니다.

        Args:
            label_points: {net_name: [(x, y), ...], ...}

        Returns:
            와이어 섹션 문자열
        """
        if not label_points:
            return ""

        wires = []
        seen_segments = set()

        for net, coords in label_points.items():
            if len(coords) < 2:
                continue

            # y -> x 기준 정렬 후 체인 연결
            sorted_coords = sorted(coords, key=lambda c: (c[1], c[0]))

            # 체인 방식 연결: [0]->[1]->[2]...
            for i in range(len(sorted_coords) - 1):
                x1, y1 = sorted_coords[i]
                x2, y2 = sorted_coords[i + 1]

                # 그리드 스냅
                x1, y1 = snap_to_grid(x1), snap_to_grid(y1)
                x2, y2 = snap_to_grid(x2), snap_to_grid(y2)

                # L자(직교) 라우팅
                wire_segs = self._create_l_route(x1, y1, x2, y2)

                for seg in wire_segs:
                    sx1, sy1, sx2, sy2 = seg
                    wire_str = self._make_wire_segment(sx1, sy1, sx2, sy2, seen_segments)
                    if wire_str:
                        wires.append(wire_str)

        if not wires:
            return ""

        return "\n".join(wires)

    def _create_l_route(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float
    ) -> list[tuple[float, float, float, float]]:
        """두 점 사이의 L자 라우팅 세그먼트를 생성합니다.

        Returns:
            [(x1, y1, x2, y2), ...] 세그먼트 리스트
        """
        segments = []

        # 같은 x 또는 같은 y면 직선 1개
        if abs(x1 - x2) < 0.01:
            # 수직선
            segments.append((x1, y1, x2, y2))
        elif abs(y1 - y2) < 0.01:
            # 수평선
            segments.append((x1, y1, x2, y2))
        else:
            # L자 라우팅: 3개 세그먼트 (수직-수평-수직)
            mid_y = snap_to_grid((y1 + y2) / 2)

            # Segment 1: (x1, y1) -> (x1, mid_y) 수직
            segments.append((x1, y1, x1, mid_y))
            # Segment 2: (x1, mid_y) -> (x2, mid_y) 수평
            segments.append((x1, mid_y, x2, mid_y))
            # Segment 3: (x2, mid_y) -> (x2, y2) 수직
            segments.append((x2, mid_y, x2, y2))

        return segments

    def _make_wire_segment(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        seen: set
    ) -> Optional[str]:
        """중복되지 않은 와이어 세그먼트를 생성합니다.

        Args:
            x1, y1, x2, y2: 시작/끝 좌표
            seen: 이미 생성된 세그먼트 집합

        Returns:
            와이어 문자열 또는 None (중복이거나 길이 0인 경우)
        """
        # 길이 0 와이어 스킵
        if abs(x1 - x2) < 0.01 and abs(y1 - y2) < 0.01:
            return None

        # 좌표 정규화 (작은 값이 먼저) - 중복 방지
        p1 = (round(x1, 2), round(y1, 2))
        p2 = (round(x2, 2), round(y2, 2))
        key = tuple(sorted([p1, p2]))

        if key in seen:
            return None

        seen.add(key)
        return SchematicTemplate.create_wire(x1, y1, x2, y2)

    def build_bom(self) -> Path:
        """JLC BOM CSV를 생성합니다 (v1.3: DNP 필터링 + 수량 그룹화)."""
        output_path = self.output_dir / "bom_jlc.csv"

        # DNP가 아닌 부품만 필터링
        active_parts = [p for p in self.parts if not p.dnp]

        # 동일 부품 그룹화: (value, footprint, lcsc) 기준
        groups = defaultdict(list)
        for part in active_parts:
            key = (part.value, part.footprint_full or "", part.lcsc or "")
            groups[key].append(part.ref)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["Comment", "Designator", "Footprint", "JLCPCB Part #"])

            for (value, footprint, lcsc), refs in groups.items():
                # Designator: 콤마로 구분된 레퍼런스 목록
                designator = ",".join(sorted(refs, key=self._natural_sort_key))
                writer.writerow([value, designator, footprint, lcsc])

        return output_path

    def build_bom_full(self) -> Path:
        """상세 BOM CSV를 생성합니다 (v1.3).

        모든 필드 포함: Ref, Value, Footprint, LCSC, MPN, Manufacturer, Description, DNP, Qty
        """
        output_path = self.output_dir / "bom_full.csv"

        # 그룹화: (value, footprint, lcsc, mpn, manufacturer) 기준
        groups = defaultdict(lambda: {"refs": [], "description": "", "dnp": False})
        for part in self.parts:
            key = (
                part.value,
                part.footprint_full or "",
                part.lcsc or "",
                part.mpn or "",
                part.manufacturer or "",
            )
            groups[key]["refs"].append(part.ref)
            if part.description:
                groups[key]["description"] = part.description
            groups[key]["dnp"] = part.dnp

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                "Designator", "Value", "Footprint", "LCSC", "MPN",
                "Manufacturer", "Description", "DNP", "Qty"
            ])

            for (value, footprint, lcsc, mpn, manufacturer), info in groups.items():
                refs = sorted(info["refs"], key=self._natural_sort_key)
                writer.writerow([
                    ",".join(refs),
                    value,
                    footprint,
                    lcsc,
                    mpn,
                    manufacturer,
                    info["description"],
                    "Yes" if info["dnp"] else "",
                    len(refs),
                ])

        return output_path

    def build_report(self, warnings: list[str] = None) -> Path:
        """빌드 리포트를 생성합니다 (v1.3).

        Args:
            warnings: 검증 경고 목록

        Returns:
            report.md 파일 경로
        """
        warnings = warnings or []
        output_path = self.output_dir / "report.md"

        # 통계 수집
        total_parts = len(self.parts)
        dnp_parts = [p for p in self.parts if p.dnp]
        active_parts = [p for p in self.parts if not p.dnp]
        with_lcsc = [p for p in active_parts if p.lcsc]
        with_mpn = [p for p in active_parts if p.mpn]

        # 부품 타입별 카운트
        type_counts = defaultdict(int)
        for part in active_parts:
            # ref prefix로 타입 추출 (R1 -> R, U1 -> U, C3 -> C)
            prefix = ''.join(c for c in part.ref if c.isalpha())
            type_counts[prefix] += 1

        lines = [
            f"# {self.config.name} Build Report",
            "",
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"**KiCad Version:** {self.config.kicad_version}",
            "",
            "## Summary",
            "",
            f"| Metric | Count |",
            f"|--------|-------|",
            f"| Total Parts | {total_parts} |",
            f"| Active Parts | {len(active_parts)} |",
            f"| DNP Parts | {len(dnp_parts)} |",
            f"| With LCSC # | {len(with_lcsc)} |",
            f"| With MPN | {len(with_mpn)} |",
            "",
            "## Parts by Type",
            "",
            "| Type | Count |",
            "|------|-------|",
        ]

        for prefix, count in sorted(type_counts.items()):
            lines.append(f"| {prefix} | {count} |")

        lines.extend([
            "",
            "## Parts List",
            "",
            "| Ref | Value | Role | LCSC | MPN | DNP |",
            "|-----|-------|------|------|-----|-----|",
        ])

        for part in sorted(self.parts, key=lambda p: self._natural_sort_key(p.ref)):
            dnp_mark = "Yes" if part.dnp else ""
            lines.append(
                f"| {part.ref} | {part.value} | {part.role} | "
                f"{part.lcsc or '-'} | {part.mpn or '-'} | {dnp_mark} |"
            )

        # DNP 부품 별도 섹션
        if dnp_parts:
            lines.extend([
                "",
                "## DNP Parts (Do Not Populate)",
                "",
                "| Ref | Value | Role |",
                "|-----|-------|------|",
            ])
            for part in dnp_parts:
                lines.append(f"| {part.ref} | {part.value} | {part.role} |")

        # 경고 섹션
        if warnings:
            lines.extend([
                "",
                "## Warnings",
                "",
            ])
            for w in warnings:
                lines.append(f"- {w}")

        # 계층 모드인 경우 시트 정보
        if self.config.is_hierarchical:
            lines.extend([
                "",
                "## Hierarchical Sheets",
                "",
                "| Sheet | Parts | Ports |",
                "|-------|-------|-------|",
            ])
            for sheet in self.config.sheets:
                ports = ", ".join(sheet.ports[:3])
                if len(sheet.ports) > 3:
                    ports += "..."
                lines.append(f"| {sheet.name} | {len(sheet.parts)} | {ports} |")

        output_path.write_text("\n".join(lines), encoding='utf-8')
        return output_path

    @staticmethod
    def _natural_sort_key(s: str):
        """자연 정렬 키 (R1, R2, R10 순서로 정렬)."""
        import re
        return [int(c) if c.isdigit() else c.lower() for c in re.split(r'(\d+)', s)]

    def build_manifest(self, generated_files: dict, warnings: list[str]) -> Path:
        """빌드 manifest를 생성합니다.

        Args:
            generated_files: 생성된 파일 경로 딕셔너리
            warnings: 검증 경고 목록

        Returns:
            manifest.json 파일 경로
        """
        # 부품별 리졸브 정보
        parts_info = []
        for part in self.parts:
            source = "unknown"
            if part.symbol_lib and part.symbol_lib.exists():
                source = "lcsc"
            elif part.symbol_name in BUILTIN_SYMBOLS:
                source = "builtin"
            else:
                source = "role_mapping"

            parts_info.append({
                "ref": part.ref,
                "role": part.role,
                "symbol": part.symbol_name,
                "footprint": part.footprint_full or "",
                "lcsc": part.lcsc or "",
                "resolve_source": source,
            })

        # 생성된 파일 목록
        files = {}
        for key, path in generated_files.items():
            if path:
                files[key] = str(path)

        manifest = {
            "version": "1.3",
            "project": self.config.name,
            "generated_at": datetime.now().isoformat(),
            "kicad_version": self.config.kicad_version,
            "parts_count": len(self.parts),
            "parts": parts_info,
            "warnings": warnings,
            "files": files,
        }

        output_path = self.output_dir / "manifest.json"
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)

        return output_path

    def _build_lib_symbols_section(self) -> str:
        """lib_symbols 섹션을 생성합니다."""
        symbols = []
        added = set()

        # 전원 심볼
        for net_name, net_value in self.config.net_presets.items():
            if net_value not in added:
                if net_value.upper() == "GND":
                    symbols.append(self._indent_symbol(BUILTIN_SYMBOLS["GND"]))
                else:
                    builtin = SymbolTemplate.get_builtin_symbol(net_value)
                    if builtin:
                        symbols.append(self._indent_symbol(builtin))
                    else:
                        symbols.append(self._indent_symbol(
                            SymbolTemplate.create_power_symbol(net_value, net_value)
                        ))
                added.add(net_value)

        # 부품 심볼
        for part in self.parts:
            sym_name = part.symbol_name
            if sym_name in added:
                continue

            # LCSC 심볼
            if part.symbol_lib and part.symbol_lib.exists():
                content = part.symbol_lib.read_text(encoding='utf-8')
                sym_content = self._extract_symbol_from_lib(content)
                if sym_content:
                    symbols.append(self._indent_symbol(sym_content))
                    added.add(sym_name)
                    continue

            # 내장 심볼
            builtin = SymbolTemplate.get_builtin_symbol(sym_name)
            if builtin:
                symbols.append(self._indent_symbol(builtin))
                added.add(sym_name)

        return "\n".join(symbols)

    def _extract_symbol_from_lib(self, content: str) -> Optional[str]:
        """라이브러리 파일에서 심볼 정의만 추출합니다."""
        import re

        # (symbol "NAME" ... ) 패턴 찾기
        pattern = r'(\(symbol\s+"[^"]+"\s+[\s\S]*?\n\))'
        matches = re.findall(pattern, content)

        if matches:
            return matches[0]

        return None

    def _indent_symbol(self, symbol: str) -> str:
        """심볼에 탭 들여쓰기를 추가합니다."""
        lines = symbol.strip().split('\n')
        return '\n'.join('\t\t' + line for line in lines)
